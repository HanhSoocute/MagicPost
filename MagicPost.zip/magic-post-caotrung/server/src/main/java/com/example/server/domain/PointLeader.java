package com.example.server.domain;

public class PointLeader {
    
}
