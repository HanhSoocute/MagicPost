package com.example.server.domain;

public enum ERole {
    ROLE_BOSS,
    ROLE_POINTLEADER,
    ROLE_TELLER,
    ROLE_STAFF,
    ROLE_CUSTOMER
}
