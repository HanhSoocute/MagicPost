import React from "react";
import BeautifulChart from "../../BeautifulChart";

const TransactionStatistic = () => {
  return (
    <>
      <BeautifulChart />
    </>
  );
};

export default TransactionStatistic;
