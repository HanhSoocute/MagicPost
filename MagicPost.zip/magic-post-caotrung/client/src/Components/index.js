export { default as Header } from './Header';
export { default as Content } from './Content';
export { default as SideBarCT } from './SideBarCT';
export { default as Profile } from './Profile';
export { default as Footer } from './Footer';
export { default as SimpleSlider } from './Slider';
export { default as AutoSlide } from './AutoSlide';






